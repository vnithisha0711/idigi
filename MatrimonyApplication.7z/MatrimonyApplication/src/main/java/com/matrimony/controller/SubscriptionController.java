package com.matrimony.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.matrimony.entity.Subscription;
import com.matrimony.exception.SubNotFoundException;
import com.matrimony.service.SubscriptionService;

@RestController
@RequestMapping("/api/subscription")
public class SubscriptionController {
	
	@Autowired
	private SubscriptionService subscriptionService;
	
	@PostMapping("/addSubscription")
	public Subscription saveSubscription(@RequestBody Subscription subscription) throws SubNotFoundException{
		Subscription response = subscriptionService.saveSubscription(subscription);
		ResponseEntity<Subscription> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);
		return response;
		
	}
	//http://localhost:9091/swagger-ui/index.html#/
	//http://localhost:9091/api/subscription/1
	@GetMapping("/getById/{subId}")
	public Subscription getById(@PathVariable int subId) {
		Subscription dto=subscriptionService.getById(subId);
		return dto;
	}
	
	//http://localhost:9091/api/subscription
	@GetMapping("/getAll")
	public List<Subscription> getAllSubscription() {
		List<Subscription> list=subscriptionService.findAll();
		return list;
	}
		
	@PutMapping("/updateSubscription/{subId}")
	public ResponseEntity<String> updateSubscription( @RequestBody Subscription subscription) throws SubNotFoundException {
		String response = subscriptionService.updateSubscription(subscription);
		ResponseEntity<String> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);
		return responseEntity;
	}
		
	@DeleteMapping("/deleteSubscription/{subId}")
	public ResponseEntity<String> deleteSubscription(@PathVariable("subId") int subId) {
		String response = subscriptionService.deleteSubscriptionById(subId);
		ResponseEntity<String> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);
		return responseEntity;
			
	       
	}
	
	@GetMapping("/getBysubMonth/{subMonth}")
	public Subscription getBysubMonth(@PathVariable("subMonth") int subMonth) {
		Subscription dto=subscriptionService.getBysubMonth(subMonth);
		return dto;
	}
		
	@GetMapping("/getBysubYear/{subYear}")
	public Subscription getBysubYear(@PathVariable("subYear") int subYear) {
		Subscription dto=subscriptionService.getBysubYear(subYear);
		return dto;
	}

}
