package com.matrimony.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.matrimony.entity.Subscription;
import com.matrimony.exception.SubNotFoundException;

@Service
public interface SubscriptionService {
	
    public Subscription saveSubscription(Subscription subscription);
	
    public Subscription getById(int subId);
    
    public List<Subscription> findAll();
  
	public String deleteSubscriptionById(int subId) ;
	
	public String updateSubscription(Subscription subscription) throws SubNotFoundException;
	
	public Subscription getBysubMonth(int subMonth);

	public Subscription getBysubYear(int subYear);

}
