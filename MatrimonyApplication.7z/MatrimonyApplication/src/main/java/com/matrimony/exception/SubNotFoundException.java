package com.matrimony.exception;

public class SubNotFoundException extends RuntimeException {

	public SubNotFoundException(String message) {
		super(message);
	}
	
	

}
