package com.matrimony.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.matrimony.entity.Subscription;
import com.matrimony.exception.SubNotFoundException;
import com.matrimony.repository.SubscriptionRepository;
import com.matrimony.service.SubscriptionService;

@Service
public class SubscriptionServiceImpl implements SubscriptionService {
	
	@Autowired
	private SubscriptionRepository subscriptionRepository;
	
	@Override
	public Subscription saveSubscription(Subscription subscription) {
		return subscriptionRepository.save(subscription);
	}

	@Override
	public Subscription getById(int subId) {
		Optional<Subscription> sub = subscriptionRepository.findById(subId);
		if(sub.isPresent()) {
			Subscription dto=new Subscription();
			BeanUtils.copyProperties(sub.get(), dto);
			return dto;
		}
		return null;
	}

	@Override
	public List<Subscription> findAll() {
		Iterable<Subscription> list=subscriptionRepository.findAll();
		List<Subscription> dtos=new ArrayList<>();
		for(Subscription sub:list) {
			Subscription dto=new Subscription();
			BeanUtils.copyProperties(sub, dto);
			dtos.add(dto);
	}
		return dtos;

	}


	@Override
	public Subscription getBysubMonth(int subMonth) {
		Optional<Subscription> sub = subscriptionRepository.findBysubMonth(subMonth);
		if(sub.isPresent()) {
			Subscription dto=new Subscription();
			BeanUtils.copyProperties(sub.get(), dto);
			return dto;
		}
		return null;
	}
	
	@Override
	public Subscription getBysubYear(int subYear) {
		Optional<Subscription> sub = subscriptionRepository.findBysubYear(subYear);
		if(sub.isPresent()) {
			Subscription dto=new Subscription();
			BeanUtils.copyProperties(sub.get(), dto);
			return dto;
		}
		return null;
	}

	@Override
	public String deleteSubscriptionById(int subId) {
		Optional<Subscription> sub = subscriptionRepository.findById(subId);
		if (sub.isEmpty()) {
			return "There is No subscription pack with Id:" + subId;
		}
		
		subscriptionRepository.deleteById(subId);
		return "subscription with Id: " +subId + " Delete Successfully";
	}

	@Override
	public String updateSubscription(Subscription subscription) throws SubNotFoundException {
		Optional<Subscription> subpack = subscriptionRepository.findById(subscription.getSubId());
		if (subpack.isEmpty()) {
			throw new SubNotFoundException("There is no subscription existed with id: " + subscription.getSubId());
		}
	
	    subscriptionRepository.save(subscription);
		return "Updated Successfully";
	}

}
