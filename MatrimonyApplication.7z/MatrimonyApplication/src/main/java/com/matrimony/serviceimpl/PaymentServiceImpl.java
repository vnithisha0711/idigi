package com.matrimony.serviceimpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.matrimony.entity.Payment;
import com.matrimony.exception.ResourceNotFoundException;
import com.matrimony.repository.PaymentRepository;
import com.matrimony.service.PaymentService;

@Service
public class PaymentServiceImpl implements PaymentService {
	
	private PaymentRepository paymentRepository;
	
	public PaymentServiceImpl(PaymentRepository paymentRepository) {
		
	    super();
		this.paymentRepository = paymentRepository;
    }

	@Override
	public Payment savePayment(Payment payment) {
		return paymentRepository.save(payment);
		
	}

	@Override
	public List<Payment> getAllPayments() {
		return (List<Payment>) paymentRepository.findAll();
		
	}

	@Override
	public Payment getPaymentById(int id) {
		return paymentRepository.findById(id).orElseThrow(() ->
		new ResourceNotFoundException("Payment Id is not found ","Id",id));
		
	}

	@Override
	public Payment updatePayment(Payment payment, int id) {
		Payment pay = paymentRepository.findById(id).orElseThrow(
				 ()-> new ResourceNotFoundException("Payment Id is not found", "Id", id));
		

		pay.setCandidateName(payment.getCandidateName());
		pay.setBankName(payment.getBankName());
		pay.setAccountNo(payment.getAccountNo());
		pay.setIfscCode(payment.getIfscCode());

		paymentRepository.save(pay);
		return pay;
		
	}


}
